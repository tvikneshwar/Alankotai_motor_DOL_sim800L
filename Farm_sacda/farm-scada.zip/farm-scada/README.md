# Farm SCADA

Browser dashboards for a farm, served by nginx on a Raspberry Pi and connected to a Mosquitto broker over MQTT WebSockets.

| Page | Purpose |
|---|---|
| `web/index.html` | Pipeline and irrigation dashboard (copy your existing file here, it is not included in this zip) |
| `web/mushroom-dashboard.html` | Oyster mushroom house: temperature, humidity, exhaust fan, mist pump |
| `web/home.html` | Landing page linking both |

Without a broker connection the mushroom page runs a built-in simulation.

## Layout

```
web/                       pages (+ vendor/ built locally, git-ignored)
firmware/mushroom-esp32/   Arduino sketch for the ESP32 controller
scripts/build-css.sh       builds web/vendor/tailwind.css for ALL pages, fetches mqtt.min.js if missing
scripts/deploy.sh          copies web/ to /var/www/scada
server/                    SQLite logger service (MQTT -> database -> /api for the dashboards)
```

## Raspberry Pi setup

```bash
git clone <your-repo-url> ~/farm-scada && cd ~/farm-scada
cp ~/scada/index.html web/index.html     # your existing pipeline page, if not committed
bash scripts/build-css.sh                # needs internet once
bash scripts/deploy.sh
```
Open `http://<pi-ip>/home.html`.

Run `build-css.sh` again whenever you add or change pages, so Tailwind picks up new classes.

### Mosquitto

Two listeners are needed: `1883` (ESP32, plain MQTT) and `9001` (dashboard, WebSockets), for example in `/etc/mosquitto/conf.d/farm.conf`:

```
listener 1883
protocol mqtt
listener 9001
protocol websockets
allow_anonymous true
```
`allow_anonymous true` is only acceptable on an isolated network. Otherwise set up a password file and per-topic ACLs (separate logins for pipeline and mushroom), because the dashboard's arm button is an operator safeguard, not security.

## Database (SQLite logger)

`server/scada_logger.py` subscribes to MQTT and stores everything in `/var/lib/scada/scada.db`. The dashboards read it through a small read-only API (`/api/...`) that nginx proxies to `127.0.0.1:8081`.

```bash
bash server/install.sh        # venv + paho-mqtt + systemd service "scada-logger"
```
Then add the `location /api/` block from `server/nginx-api.conf` to the nginx server block that has `root /var/www/scada;` and run `sudo nginx -t && sudo systemctl reload nginx`. Rebuild and deploy the pages (`build-css.sh`, `deploy.sh`) because the mushroom page gained new buttons.

What is stored
- Mushroom temperature, humidity, fan and pump state every 10 s (raw kept 30 days) plus hourly min/avg/max summaries and fan/pump run time (kept forever).
- Pipeline pressure, flow and well level every 30 s (raw kept 30 days) and a row whenever any valve or pump changes state.
- Every command published on `farm/+/control` (who-did-what audit trail, kept 1 year).
- Alarm raise/clear events (high temperature, low humidity, sensor fault, low well level, telemetry stale), kept 1 year.

Checks and tools
```bash
curl http://127.0.0.1:8081/api/health
journalctl -u scada-logger -f
sqlite3 /var/lib/scada/scada.db "select datetime(ts,'unixepoch','localtime'),temp,rh from mushroom_readings order by ts desc limit 5"
```
API: `/api/health`, `/api/mushroom/history?minutes=60`, `/api/mushroom/daily?days=30`, `/api/pipeline/history?minutes=60`, `/api/events?limit=50`, `/api/commands`, `/api/export/mushroom.csv?days=7`.

Settings go in `/etc/default/scada-logger` (`MQTT_USER=...`, `MQTT_PASS=...`, `MQTT_HOST`, `MQTT_PORT`, `MQTT_TRANSPORT=tcp`, `SCADA_DB`). By default it connects to the Mosquitto WebSocket listener on 9001.

Backup: copy the database safely with `sqlite3 /var/lib/scada/scada.db ".backup '/home/pi/scada-backup.db'"`. For long-term reliability, move `/var/lib/scada` to a USB SSD, since an SD card wears out under constant writes (the logger already batches commits every 15 s).

## Mushroom controller (ESP32)

1. Arduino IDE libraries: PubSubClient, ArduinoJson (v7), Adafruit SHT31 Library.
2. In `firmware/mushroom-esp32/`, copy `secrets.h.example` to `secrets.h` and edit it.
3. Wiring: SHT31 SDA=GPIO21, SCL=GPIO22, 3.3V, GND. Fan relay IN=GPIO26. Pump relay IN=GPIO27. Relays are assumed active-low (swap `RELAY_ON`/`RELAY_OFF` if not).
4. Flash, then open the mushroom page. It should show MQTT LIVE CONNECTED.

The AUTO logic runs on the ESP32, so the room keeps working without Wi-Fi or the Pi. A stuck pump is limited by a hard burst cap and cooldown; if the sensor fails for 30 s the pump is forced off and the fan runs.

### MQTT topics

- `farm/mushroom/status` (ESP32 publishes every 3 s): `{"temp":27.8,"rh":86.2,"fan":"ON","pump":"OFF","mode":{"fan":"AUTO","pump":"AUTO"},"sp":{...},"totals":{"fanSec":0,"pumpSec":0},"sensorFault":false}`
- `farm/mushroom/control` (dashboard publishes):
  - `{"device":"fan","command":"ON"}` or `"OFF"` (MANUAL mode only)
  - `{"op":"setMode","device":"pump","mode":"AUTO"}`
  - `{"op":"setSetpoints","sp":{"rhMin":82,"rhMax":92,"tMax":30,"fanEvery":30,"fanFor":3,"pumpMax":30}}`

## Safety

Fuse and enclose the pump and fan supplies, put an RCD/ELCB on the mains, and test first with the loads unplugged while listening to the relays.
