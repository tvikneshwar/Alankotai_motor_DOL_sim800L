#!/usr/bin/env python3
"""SCADA logger: MQTT -> SQLite, plus a small read-only JSON API for the dashboards.

Runs on the Raspberry Pi next to Mosquitto. nginx proxies /api/ to 127.0.0.1:8081.
Standard library + paho-mqtt only.
"""
import csv, io, json, os, signal, sqlite3, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import paho.mqtt.client as mqtt

DB_PATH = os.environ.get("SCADA_DB", "/var/lib/scada/scada.db")
MQTT_HOST = os.environ.get("MQTT_HOST", "127.0.0.1")
MQTT_PORT = int(os.environ.get("MQTT_PORT", "9001"))
MQTT_TRANSPORT = os.environ.get("MQTT_TRANSPORT", "websockets")   # the 9001 listener already works; use "tcp" with port 1883 if you prefer
MQTT_USER = os.environ.get("MQTT_USER") or None
MQTT_PASS = os.environ.get("MQTT_PASS") or None
API_PORT = int(os.environ.get("API_PORT", "8081"))

MUSH_EVERY, PIPE_EVERY = 10, 30      # seconds between stored samples
RAW_DAYS, LOG_DAYS = 30, 365         # raw readings kept 30 days (hourly summaries kept forever); events/commands 1 year
STALE_SEC = 30
COMMIT_EVERY = 15                    # batch commits to spare the SD card

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS mushroom_readings(ts INTEGER PRIMARY KEY, temp REAL, rh REAL, fan INTEGER, pump INTEGER);
CREATE TABLE IF NOT EXISTS mushroom_hourly(hour INTEGER PRIMARY KEY, n INTEGER, t_sum REAL, t_min REAL, t_max REAL,
  rh_sum REAL, rh_min REAL, rh_max REAL, fan_n INTEGER, pump_n INTEGER);
CREATE TABLE IF NOT EXISTS pipeline_readings(ts INTEGER PRIMARY KEY, pressure REAL, flow REAL, well_level INTEGER, well_pct REAL, pump1 INTEGER);
CREATE TABLE IF NOT EXISTS pipeline_states(ts INTEGER PRIMARY KEY, state TEXT);
CREATE TABLE IF NOT EXISTS commands(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, topic TEXT, payload TEXT);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, source TEXT, sev TEXT, kind TEXT, msg TEXT);
CREATE INDEX IF NOT EXISTS ix_events_ts ON events(ts);
"""


def now():
    return int(time.time())


def num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def log(*a):
    print(time.strftime("%F %T"), *a, flush=True)


class Store:
    """Single writer connection; commits are batched."""

    def __init__(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        self.c = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10)
        self.c.executescript(SCHEMA)
        self.c.execute("PRAGMA synchronous=NORMAL")
        self.lock = threading.Lock()
        self.dirty = False

    def run(self, sql, args=()):
        with self.lock:
            self.c.execute(sql, args)
            self.dirty = True

    def commit(self):
        with self.lock:
            if self.dirty:
                self.c.commit()
                self.dirty = False


store = None
active = {}                                  # alarm key -> message
last = {"mush": 0, "pipe": 0, "state": None}
seen = {"mushroom": 0, "pipeline": 0}


def alarm(source, key, sev, msg, on):
    k = source + ":" + key
    if on and k not in active:
        active[k] = msg
        store.run("INSERT INTO events(ts,source,sev,kind,msg) VALUES(?,?,?,?,?)", (now(), source, sev, "raise", msg))
        log("ALARM", source, sev, msg)
    elif not on and k in active:
        old = active.pop(k)
        store.run("INSERT INTO events(ts,source,sev,kind,msg) VALUES(?,?,?,?,?)", (now(), source, "info", "clear", "Cleared: " + old))


def on_mushroom(d):
    t = now()
    seen["mushroom"] = t
    alarm("mushroom", "stale", "crit", "No telemetry for more than %d s" % STALE_SEC, False)
    alarm("mushroom", "fault", "crit", "Controller reports sensor fault", bool(d.get("sensorFault")))
    temp, rh = d.get("temp"), d.get("rh")
    if not (num(temp) and num(rh)) or not (-20 <= temp <= 80 and 0 <= rh <= 100):
        return
    sp = d.get("sp") or {}
    tmax, rmin = sp.get("tMax", 30), sp.get("rhMin", 82)
    alarm("mushroom", "t_warn", "warn", "Temperature high: %.1f C" % temp, temp > tmax + 1)
    alarm("mushroom", "t_crit", "crit", "Temperature very high: %.1f C" % temp, temp > tmax + 4)
    alarm("mushroom", "h_warn", "warn", "Humidity low: %.0f %%" % rh, rh < rmin - 5)
    alarm("mushroom", "h_crit", "crit", "Humidity very low: %.0f %%" % rh, rh < rmin - 12)
    if t - last["mush"] < MUSH_EVERY:
        return
    last["mush"] = t
    fan = 1 if d.get("fan") == "ON" else 0
    pump = 1 if d.get("pump") == "ON" else 0
    store.run("INSERT OR REPLACE INTO mushroom_readings VALUES(?,?,?,?,?)", (t, temp, rh, fan, pump))
    store.run("""INSERT INTO mushroom_hourly(hour,n,t_sum,t_min,t_max,rh_sum,rh_min,rh_max,fan_n,pump_n)
                 VALUES(?,1,?,?,?,?,?,?,?,?)
                 ON CONFLICT(hour) DO UPDATE SET n=n+1, t_sum=t_sum+excluded.t_sum,
                   t_min=MIN(t_min,excluded.t_min), t_max=MAX(t_max,excluded.t_max),
                   rh_sum=rh_sum+excluded.rh_sum, rh_min=MIN(rh_min,excluded.rh_min), rh_max=MAX(rh_max,excluded.rh_max),
                   fan_n=fan_n+excluded.fan_n, pump_n=pump_n+excluded.pump_n""",
              (t // 3600 * 3600, temp, temp, temp, rh, rh, rh, fan, pump))


def on_pipeline(d):
    t = now()
    seen["pipeline"] = t
    alarm("pipeline", "stale", "crit", "No telemetry for more than %d s" % STALE_SEC, False)
    wl = d.get("wellLevel")
    if num(wl):
        alarm("pipeline", "well_low", "warn", "Well level L%d low" % wl, wl <= 2)
        alarm("pipeline", "well_crit", "crit", "Well level L%d critical" % wl, wl <= 1)
    if t - last["pipe"] >= PIPE_EVERY:
        last["pipe"] = t
        g = lambda k: d.get(k) if num(d.get(k)) else None
        store.run("INSERT OR REPLACE INTO pipeline_readings VALUES(?,?,?,?,?,?)",
                  (t, g("pressurePSI"), g("totalFlowLpm"), g("wellLevel"), g("wellVolumePct"), 1 if d.get("pump1") == "ON" else 0))
    states = {k: v for k, v in d.items() if (k == "pump1" or k.startswith("valve")) and isinstance(v, str)}
    s = json.dumps(states, sort_keys=True)
    if states and s != last["state"]:
        last["state"] = s
        store.run("INSERT OR REPLACE INTO pipeline_states VALUES(?,?)", (t, s))


def on_message(client, userdata, msg):
    try:
        text = msg.payload.decode("utf-8", "replace")
        if msg.topic.endswith("/control"):
            store.run("INSERT INTO commands(ts,topic,payload) VALUES(?,?,?)", (now(), msg.topic, text[:500]))
            return
        d = json.loads(text)
        if not isinstance(d, dict):
            return
        if msg.topic == "farm/mushroom/status":
            on_mushroom(d)
        elif msg.topic == "farm/pipeline/status":
            on_pipeline(d)
    except Exception as e:                    # never let one bad message stop logging
        log("message error:", repr(e))


def on_connect(client, userdata, flags, rc, *extra):
    log("MQTT connected", rc)
    client.subscribe([("farm/mushroom/status", 1), ("farm/pipeline/status", 1), ("farm/+/control", 1)])


def make_client():
    kw = {"transport": MQTT_TRANSPORT, "client_id": "scada-logger"}
    try:
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, **kw)   # paho-mqtt 2.x
    except AttributeError:
        c = mqtt.Client(**kw)                                     # paho-mqtt 1.x
    if MQTT_USER:
        c.username_pw_set(MQTT_USER, MQTT_PASS)
    c.on_connect, c.on_message = on_connect, on_message
    c.reconnect_delay_set(1, 30)
    c.connect_async(MQTT_HOST, MQTT_PORT, keepalive=30)
    c.loop_start()
    return c


def purge():
    raw, lg = now() - RAW_DAYS * 86400, now() - LOG_DAYS * 86400
    for sql, cut in [("DELETE FROM mushroom_readings WHERE ts<?", raw), ("DELETE FROM pipeline_readings WHERE ts<?", raw),
                     ("DELETE FROM pipeline_states WHERE ts<?", lg), ("DELETE FROM commands WHERE ts<?", lg),
                     ("DELETE FROM events WHERE ts<?", lg)]:
        store.run(sql, (cut,))


def housekeeping(stop):
    ticks = 0
    while not stop.wait(5):
        ticks += 5
        for src in ("mushroom", "pipeline"):
            if seen[src]:
                alarm(src, "stale", "crit", "No telemetry for more than %d s" % STALE_SEC, now() - seen[src] > STALE_SEC)
        if ticks % COMMIT_EVERY < 5:
            store.commit()
        if ticks % 21600 < 5:
            purge()


# ---------------- read-only API ----------------
def q(sql, args=()):
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    try:
        c.execute("PRAGMA query_only=1")
        return [dict(r) for r in c.execute(sql, args)]
    finally:
        c.close()


def geti(p, name, default, lo, hi):
    try:
        v = int(p.get(name, [default])[0])
    except ValueError:
        v = default
    return max(lo, min(hi, v))


def series(rows, *cols):
    out = {"ts": [r["ts"] for r in rows]}
    for c in cols:
        out[c] = [None if r[c] is None else round(r[c], 2) for r in rows]
    return out


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def reply(self, code, body, ctype="application/json", extra=None):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        u = urlparse(self.path)
        p, path = parse_qs(u.query), u.path.rstrip("/")
        try:
            if path == "/api/health":
                return self.reply(200, {
                    "ok": True, "now": now(),
                    "mushroom_last": q("SELECT MAX(ts) AS t FROM mushroom_readings")[0]["t"],
                    "pipeline_last": q("SELECT MAX(ts) AS t FROM pipeline_readings")[0]["t"],
                    "db_bytes": os.path.getsize(DB_PATH)})
            if path == "/api/mushroom/history":
                mins, pts = geti(p, "minutes", 60, 1, 43200), geti(p, "points", 200, 10, 1000)
                since = now() - mins * 60
                if mins > 4320:               # more than 3 days: use the hourly summaries
                    rows = q("SELECT hour AS ts, t_sum/n AS temp, rh_sum/n AS rh FROM mushroom_hourly WHERE hour>=? ORDER BY hour", (since,))
                else:
                    b = max(MUSH_EVERY, mins * 60 // pts)
                    rows = q("SELECT (ts/?)*? AS ts, AVG(temp) AS temp, AVG(rh) AS rh FROM mushroom_readings WHERE ts>=? GROUP BY 1 ORDER BY 1", (b, b, since))
                return self.reply(200, series(rows, "temp", "rh"))
            if path == "/api/mushroom/daily":
                days = geti(p, "days", 30, 1, 365)
                rows = q("""SELECT strftime('%Y-%m-%d',hour,'unixepoch','localtime') AS day,
                              SUM(t_sum)/SUM(n) AS t_avg, MIN(t_min) AS t_min, MAX(t_max) AS t_max,
                              SUM(rh_sum)/SUM(n) AS rh_avg, MIN(rh_min) AS rh_min, MAX(rh_max) AS rh_max,
                              SUM(fan_n)*?/60.0 AS fan_min, SUM(pump_n)*?/60.0 AS pump_min
                            FROM mushroom_hourly WHERE hour>=? GROUP BY day ORDER BY day""", (MUSH_EVERY, MUSH_EVERY, now() - days * 86400))
                return self.reply(200, [{k: (round(v, 1) if isinstance(v, float) else v) for k, v in r.items()} for r in rows])
            if path == "/api/pipeline/history":
                mins, pts = geti(p, "minutes", 60, 1, 43200), geti(p, "points", 200, 10, 1000)
                b = max(PIPE_EVERY, mins * 60 // pts)
                rows = q("""SELECT (ts/?)*? AS ts, AVG(pressure) AS pressure, AVG(flow) AS flow, AVG(well_pct) AS well_pct
                            FROM pipeline_readings WHERE ts>=? GROUP BY 1 ORDER BY 1""", (b, b, now() - mins * 60))
                return self.reply(200, series(rows, "pressure", "flow", "well_pct"))
            if path == "/api/events":
                lim = geti(p, "limit", 50, 1, 500)
                src = p.get("source", [None])[0]
                rows = q("SELECT ts,source,sev,kind,msg FROM events" + (" WHERE source=?" if src else "") + " ORDER BY id DESC LIMIT ?",
                         ((src, lim) if src else (lim,)))
                return self.reply(200, rows)
            if path == "/api/commands":
                return self.reply(200, q("SELECT ts,topic,payload FROM commands ORDER BY id DESC LIMIT ?", (geti(p, "limit", 50, 1, 500),)))
            if path == "/api/export/mushroom.csv":
                days = geti(p, "days", 7, 1, RAW_DAYS)
                rows = q("SELECT datetime(ts,'unixepoch','localtime') AS time,temp,rh,fan,pump FROM mushroom_readings WHERE ts>=? ORDER BY ts", (now() - days * 86400,))
                buf = io.StringIO()
                w = csv.writer(buf)
                w.writerow(["time", "temp_c", "rh_pct", "fan", "pump"])
                for r in rows:
                    w.writerow([r["time"], r["temp"], r["rh"], r["fan"], r["pump"]])
                return self.reply(200, buf.getvalue().encode(), "text/csv",
                                  {"Content-Disposition": 'attachment; filename="mushroom-%dd.csv"' % days})
            self.reply(404, {"error": "not found"})
        except Exception as e:
            self.reply(500, {"error": str(e)})


def main():
    global store
    store = Store()
    purge()
    stop = threading.Event()
    client = make_client()
    threading.Thread(target=housekeeping, args=(stop,), daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", API_PORT), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log("scada-logger running: db=%s api=127.0.0.1:%d mqtt=%s:%d (%s)" % (DB_PATH, API_PORT, MQTT_HOST, MQTT_PORT, MQTT_TRANSPORT))
    signal.signal(signal.SIGTERM, lambda *a: stop.set())
    signal.signal(signal.SIGINT, lambda *a: stop.set())
    stop.wait()
    client.loop_stop()
    srv.shutdown()
    store.commit()
    log("stopped")


if __name__ == "__main__":
    main()
