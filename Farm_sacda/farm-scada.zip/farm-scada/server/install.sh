#!/usr/bin/env bash
# Installs the SQLite logger as a systemd service. Run on the Pi from the repo root:  bash server/install.sh
set -euo pipefail
cd "$(dirname "$0")"
HERE="$(pwd)"; U="${SUDO_USER:-$USER}"
python3 -m venv .venv 2>/dev/null || { sudo apt-get install -y python3-venv; python3 -m venv .venv; }
.venv/bin/pip install -r requirements.txt
sudo mkdir -p /var/lib/scada && sudo chown "$U":"$U" /var/lib/scada
sudo tee /etc/systemd/system/scada-logger.service >/dev/null <<UNIT
[Unit]
Description=SCADA MQTT to SQLite logger
After=network.target mosquitto.service

[Service]
User=$U
EnvironmentFile=-/etc/default/scada-logger
ExecStart=$HERE/.venv/bin/python $HERE/scada_logger.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now scada-logger
sleep 2
systemctl --no-pager status scada-logger | head -n 12 || true
echo
echo "Next: add the /api/ block from server/nginx-api.conf to your nginx server block, then:"
echo "  sudo nginx -t && sudo systemctl reload nginx"
echo "Test: curl http://127.0.0.1:8081/api/health"
