#!/usr/bin/env bash
# Rebuilds vendor/tailwind.css so it covers EVERY .html file in this folder
# (pipeline index.html, mushroom-dashboard.html, home.html).
# Run from the repo root:  bash scripts/build-css.sh
# Needs internet once (downloads the Tailwind 3.4.17 standalone CLI, and mqtt.min.js only if missing).
set -euo pipefail
cd "$(dirname "$0")/../web"
mkdir -p vendor .build

case "$(uname -m)" in
  aarch64|arm64) A=arm64 ;;
  armv7l)        A=armv7 ;;
  x86_64)        A=x64 ;;
  *) echo "Unsupported CPU: $(uname -m)"; exit 1 ;;
esac

if [ ! -x .build/tailwindcss ]; then
  curl -fL -o .build/tailwindcss "https://github.com/tailwindlabs/tailwindcss/releases/download/v3.4.17/tailwindcss-linux-$A"
  chmod +x .build/tailwindcss
fi

cat > .build/tailwind.config.js <<'EOF'
module.exports = { content: ['./*.html'], theme: { extend: {} }, plugins: [] };
EOF
printf '@tailwind base;\n@tailwind components;\n@tailwind utilities;\n' > .build/input.css

.build/tailwindcss -c .build/tailwind.config.js -i .build/input.css -o vendor/tailwind.css --minify

if [ ! -s vendor/mqtt.min.js ]; then
  curl -fL -o vendor/mqtt.min.js "https://cdn.jsdelivr.net/npm/mqtt@5.10.1/dist/mqtt.min.js"
fi

ls -la vendor
echo "Done. Hard-refresh the browser (Ctrl+Shift+R)."
