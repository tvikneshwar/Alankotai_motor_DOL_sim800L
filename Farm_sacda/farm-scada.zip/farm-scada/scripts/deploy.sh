#!/usr/bin/env bash
# Copies the dashboards to the folder nginx serves. Run on the Raspberry Pi from the repo root:
#   bash scripts/deploy.sh            (default target /var/www/scada)
#   bash scripts/deploy.sh /some/dir  (another target)
set -euo pipefail
cd "$(dirname "$0")/.."
DEST="${1:-/var/www/scada}"
[ -s web/vendor/tailwind.css ] || { echo "web/vendor missing. Run: bash scripts/build-css.sh"; exit 1; }
sudo mkdir -p "$DEST/vendor"
sudo cp web/*.html "$DEST/"
sudo cp web/vendor/tailwind.css "$DEST/vendor/"
[ -s "$DEST/vendor/mqtt.min.js" ] || sudo cp web/vendor/mqtt.min.js "$DEST/vendor/"
sudo chmod -R a+rX "$DEST"
echo "Deployed to $DEST"
