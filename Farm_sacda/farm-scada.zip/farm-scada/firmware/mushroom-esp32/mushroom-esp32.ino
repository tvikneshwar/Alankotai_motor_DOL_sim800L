// Mushroom house controller - ESP32 (Arduino IDE)
// Libraries (Library Manager): PubSubClient, ArduinoJson (v7), Adafruit SHT31 Library (+ Adafruit BusIO)
// Wiring: SHT31 SDA=GPIO21, SCL=GPIO22, 3.3V, GND | Fan relay IN=GPIO26 | Pump relay IN=GPIO27
// The AUTO logic runs HERE, so the room keeps working if Wi-Fi, the Pi or the dashboard is down.

#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Adafruit_SHT31.h>
#include <Preferences.h>
#include <time.h>

// Wi-Fi and broker settings live in secrets.h (copy secrets.h.example to secrets.h and edit; secrets.h is git-ignored)
#include "secrets.h"

const char* T_STATUS = "farm/mushroom/status";
const char* T_CTRL   = "farm/mushroom/control";
#define FAN_PIN  26
#define PUMP_PIN 27
#define RELAY_ON  LOW    // most relay boards are active-LOW; swap if yours is active-HIGH
#define RELAY_OFF HIGH

struct Setpoints { float rhMin = 82, rhMax = 92, tMax = 30, fanEvery = 30, fanFor = 3, pumpMax = 30; } sp;

Adafruit_SHT31 sht;
WiFiClient net;
PubSubClient mqtt(net);
Preferences prefs;

float temp = NAN, rh = NAN;
bool sensorFault = false, fanOn = false, pumpOn = false, autoFan = true, autoPump = true;
uint32_t lastGood = 0, lastRead = 0, lastCtl = 0, lastPub = 0, lastNet = 0;
uint32_t pumpSince = 0, pumpLockStart = 0, lastCycle = 0, cycleEnd = 0;
bool pumpLocked = false, inCycle = false, pubNow = false;
uint32_t fanSec = 0, pumpSec = 0;
int lastDay = -1;

void drive() {
  digitalWrite(FAN_PIN, fanOn ? RELAY_ON : RELAY_OFF);
  digitalWrite(PUMP_PIN, pumpOn ? RELAY_ON : RELAY_OFF);
}

void loadSp() {
  prefs.begin("mush", true);
  if (prefs.getBytesLength("sp") == sizeof(sp)) prefs.getBytes("sp", &sp, sizeof(sp));
  prefs.end();
}
void saveSp() {
  prefs.begin("mush", false);
  prefs.putBytes("sp", &sp, sizeof(sp));
  prefs.end();
}

bool spValid(const Setpoints& s) {
  return s.rhMin >= 30 && s.rhMin < s.rhMax && s.rhMax <= 98 && s.tMax >= 15 && s.tMax <= 40 &&
         s.fanEvery >= 1 && s.fanEvery <= 720 && s.fanFor >= 0 && s.fanFor <= 60 &&
         s.pumpMax >= 1 && s.pumpMax <= 120;
}

void startPump(uint32_t now) {
  if (pumpLocked) return;
  pumpOn = true; pumpSince = now;
}

void control(uint32_t now) {
  // Pump: hard burst cap and cooldown apply in AUTO and MANUAL
  if (pumpLocked && now - pumpLockStart > 20000) pumpLocked = false;
  if (pumpOn && now - pumpSince > (uint32_t)(sp.pumpMax * 1000)) { pumpOn = false; pumpLocked = true; pumpLockStart = now; }

  if (sensorFault) {            // fail-safe: no misting without a reading, ventilate instead
    pumpOn = false;
    if (autoFan) fanOn = true;
  } else {
    if (autoPump) {
      if (pumpOn && rh >= sp.rhMax) pumpOn = false;
      else if (!pumpOn && rh < sp.rhMin) startPump(now);
    }
    if (autoFan) {
      if (!inCycle && now - lastCycle > (uint32_t)(sp.fanEvery * 60000UL)) { inCycle = true; cycleEnd = now + (uint32_t)(sp.fanFor * 60000UL); lastCycle = now; }
      if (inCycle && (int32_t)(now - cycleEnd) >= 0) inCycle = false;
      bool hot = temp > sp.tMax || (fanOn && temp > sp.tMax - 1);
      fanOn = hot || inCycle;
    }
  }
  drive();
}

void publishStatus() {
  if (!mqtt.connected()) return;
  JsonDocument d;
  if (!isnan(temp)) d["temp"] = round(temp * 10) / 10.0;
  if (!isnan(rh)) d["rh"] = round(rh * 10) / 10.0;
  d["fan"] = fanOn ? "ON" : "OFF";
  d["pump"] = pumpOn ? "ON" : "OFF";
  d["mode"]["fan"] = autoFan ? "AUTO" : "MANUAL";
  d["mode"]["pump"] = autoPump ? "AUTO" : "MANUAL";
  d["sp"]["rhMin"] = sp.rhMin; d["sp"]["rhMax"] = sp.rhMax; d["sp"]["tMax"] = sp.tMax;
  d["sp"]["fanEvery"] = sp.fanEvery; d["sp"]["fanFor"] = sp.fanFor; d["sp"]["pumpMax"] = sp.pumpMax;
  d["totals"]["fanSec"] = fanSec; d["totals"]["pumpSec"] = pumpSec;
  d["sensorFault"] = sensorFault;
  char buf[512];
  size_t n = serializeJson(d, buf, sizeof(buf));
  mqtt.publish(T_STATUS, (const uint8_t*)buf, n, false);
}

void onMsg(char* topic, byte* payload, unsigned int len) {
  JsonDocument d;
  if (deserializeJson(d, payload, len)) return;
  uint32_t now = millis();
  const char* op = d["op"] | "";
  const char* dev = d["device"] | "";

  if (!strcmp(op, "setMode")) {
    bool a = !strcmp(d["mode"] | "", "AUTO");
    if (!strcmp(dev, "fan")) autoFan = a;
    if (!strcmp(dev, "pump")) autoPump = a;
  } else if (!strcmp(op, "setSetpoints")) {
    Setpoints n = sp;
    JsonObject o = d["sp"];
    n.rhMin = o["rhMin"] | n.rhMin; n.rhMax = o["rhMax"] | n.rhMax; n.tMax = o["tMax"] | n.tMax;
    n.fanEvery = o["fanEvery"] | n.fanEvery; n.fanFor = o["fanFor"] | n.fanFor; n.pumpMax = o["pumpMax"] | n.pumpMax;
    if (spValid(n)) { sp = n; saveSp(); }
  } else if (!strcmp(dev, "fan") && !autoFan) {
    fanOn = !strcmp(d["command"] | "", "ON");
  } else if (!strcmp(dev, "pump") && !autoPump && !sensorFault) {
    if (!strcmp(d["command"] | "", "ON")) startPump(now); else pumpOn = false;
  }
  control(now);
  pubNow = true;
}

void netTick(uint32_t now) {
  if (now - lastNet < 5000) return;
  lastNet = now;
  if (WiFi.status() != WL_CONNECTED) { WiFi.disconnect(); WiFi.begin(WIFI_SSID, WIFI_PASS); return; }
  if (!mqtt.connected()) {
    String id = "mush-esp-" + String((uint32_t)ESP.getEfuseMac(), HEX);
    bool ok = strlen(MQTT_USER) ? mqtt.connect(id.c_str(), MQTT_USER, MQTT_PASS) : mqtt.connect(id.c_str());
    if (ok) mqtt.subscribe(T_CTRL, 1);
  }
}

void setup() {
  pinMode(FAN_PIN, OUTPUT); pinMode(PUMP_PIN, OUTPUT);
  drive();                                  // both OFF at boot
  Serial.begin(115200);
  loadSp();
  Wire.begin(21, 22);
  if (!sht.begin(0x44)) sht.begin(0x45);
  WiFi.mode(WIFI_STA); WiFi.begin(WIFI_SSID, WIFI_PASS);
  configTime(19800, 0, "pool.ntp.org");     // IST, used only to reset daily totals at midnight
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMsg);
  mqtt.setBufferSize(768);
  lastCycle = lastGood = millis();
}

void loop() {
  uint32_t now = millis();
  netTick(now);
  if (mqtt.connected()) mqtt.loop();

  if (now - lastRead >= 2000) {
    lastRead = now;
    float t = sht.readTemperature(), h = sht.readHumidity();
    if (!isnan(t) && !isnan(h)) { temp = t; rh = h; lastGood = now; sensorFault = false; }
    else if (now - lastGood > 30000) sensorFault = true;
  }

  if (now - lastCtl >= 1000) {
    lastCtl = now;
    control(now);
    if (fanOn) fanSec++;
    if (pumpOn) pumpSec++;
    struct tm tm;
    if (getLocalTime(&tm, 0)) {
      if (lastDay >= 0 && tm.tm_mday != lastDay) { fanSec = 0; pumpSec = 0; }
      lastDay = tm.tm_mday;
    }
  }

  if (pubNow || now - lastPub >= 3000) { lastPub = now; pubNow = false; publishStatus(); }
}
