# Farm SCADA

Browser dashboards for a farm, served by nginx on a Raspberry Pi and connected to a Mosquitto broker over MQTT WebSockets.

| Page | Purpose |
|---|---|
| `web/index.html` | Pipeline and irrigation dashboard (copy your existing file here, it is not included in this zip) |
| `web/mushroom-dashboard.html` | Oyster mushroom house: temperature, humidity, exhaust fan, mist pump |
| `web/home.html` | Landing page linking both |

Without a broker connection the mushroom page runs a built-in simulation.

## Layout

```
web/                       pages (+ vendor/ built locally, git-ignored)
firmware/mushroom-esp32/   Arduino sketch for the ESP32 controller
scripts/build-css.sh       builds web/vendor/tailwind.css for ALL pages, fetches mqtt.min.js if missing
scripts/deploy.sh          copies web/ to /var/www/scada
```

## Raspberry Pi setup

```bash
git clone <your-repo-url> ~/farm-scada && cd ~/farm-scada
cp ~/scada/index.html web/index.html     # your existing pipeline page, if not committed
bash scripts/build-css.sh                # needs internet once
bash scripts/deploy.sh
```
Open `http://<pi-ip>/home.html`.

Run `build-css.sh` again whenever you add or change pages, so Tailwind picks up new classes.

### Mosquitto

Two listeners are needed: `1883` (ESP32, plain MQTT) and `9001` (dashboard, WebSockets), for example in `/etc/mosquitto/conf.d/farm.conf`:

```
listener 1883
protocol mqtt
listener 9001
protocol websockets
allow_anonymous true
```
`allow_anonymous true` is only acceptable on an isolated network. Otherwise set up a password file and per-topic ACLs (separate logins for pipeline and mushroom), because the dashboard's arm button is an operator safeguard, not security.

## Mushroom controller (ESP32)

1. Arduino IDE libraries: PubSubClient, ArduinoJson (v7), Adafruit SHT31 Library.
2. In `firmware/mushroom-esp32/`, copy `secrets.h.example` to `secrets.h` and edit it.
3. Wiring: SHT31 SDA=GPIO21, SCL=GPIO22, 3.3V, GND. Fan relay IN=GPIO26. Pump relay IN=GPIO27. Relays are assumed active-low (swap `RELAY_ON`/`RELAY_OFF` if not).
4. Flash, then open the mushroom page. It should show MQTT LIVE CONNECTED.

The AUTO logic runs on the ESP32, so the room keeps working without Wi-Fi or the Pi. A stuck pump is limited by a hard burst cap and cooldown; if the sensor fails for 30 s the pump is forced off and the fan runs.

### MQTT topics

- `farm/mushroom/status` (ESP32 publishes every 3 s): `{"temp":27.8,"rh":86.2,"fan":"ON","pump":"OFF","mode":{"fan":"AUTO","pump":"AUTO"},"sp":{...},"totals":{"fanSec":0,"pumpSec":0},"sensorFault":false}`
- `farm/mushroom/control` (dashboard publishes):
  - `{"device":"fan","command":"ON"}` or `"OFF"` (MANUAL mode only)
  - `{"op":"setMode","device":"pump","mode":"AUTO"}`
  - `{"op":"setSetpoints","sp":{"rhMin":82,"rhMax":92,"tMax":30,"fanEvery":30,"fanFor":3,"pumpMax":30}}`

## Safety

Fuse and enclose the pump and fan supplies, put an RCD/ELCB on the mains, and test first with the loads unplugged while listening to the relays.
